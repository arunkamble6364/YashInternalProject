package com.main;

import java.sql.*;
import java.util.*;

public class AccountDetails {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Account Number");
		int ano = sc.nextInt();

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/arun", "root", "Arun1234@");
		Statement st = con.createStatement();

		ResultSet rs = st.executeQuery("select * from account where accountno =" + ano);
		if (rs.next()) {
			System.out.println("account no:     " + rs.getInt(1));
			System.out.println("acc holder name:" + rs.getString(2));
			System.out.println("balance :       " + rs.getFloat(3));
			//System.out.println("address:        " + rs.getString(4));
		} else
			System.out.println("account doesnot exist");

		rs.close();
		st.close();
		con.close();

	}

}
