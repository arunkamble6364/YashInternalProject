package com.main;

import java.sql.*;
public class UpdateAccount {

	public static void main(String[] args)throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		 Class.forName("com.mysql.cj.jdbc.Driver");
	     Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/arun","root", "Arun1234@");
	     Statement st = con.createStatement();
	     
	     int rows = st.executeUpdate ("update account set balance = balance+1000");
	        System.out.println (rows + " rows modified");    
	        st.close ();    
	        con.close ();
	     
	}

}
