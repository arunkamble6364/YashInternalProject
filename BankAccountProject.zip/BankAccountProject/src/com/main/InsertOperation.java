package com.main;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;
public class InsertOperation {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		 Class.forName("com.mysql.cj.jdbc.Driver");
	     Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/arun","root", "Arun1234@");
	     Statement st = con.createStatement();
	        int c = st.executeUpdate("insert into account values(1002, 'Akshay', 3000)");
	        System.out.println(c + "account stored successfully");
	        int c1 = st.executeUpdate("insert into account values(1003, 'Ravi', 6000)");
	        System.out.println(c1 + " more account stored successfully");
	        st.close();
	        con.close();
		
		
		

	}

}
