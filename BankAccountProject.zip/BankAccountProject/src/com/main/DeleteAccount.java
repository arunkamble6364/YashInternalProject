package com.main;

import java.sql.*;
import java.util.*;

public class DeleteAccount {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Account Number");
		int ano = sc.nextInt();

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/arun", "root", "Arun1234@");
		Statement st = con.createStatement();

		int c = st.executeUpdate("delete from account where accountno =" + ano);
		if (c == 0)
			System.out.println("account doesnot exist");
		else
			System.out.println("account deleted successfully");
		st.close();
		con.close();

	}

}
